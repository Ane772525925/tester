// 数据库处理
var mysql = require('mysql');


//打开数据库连接
function openCon() {
    var con = mysql.createConnection({
        host: '127.0.0.1',
        user: 'root',
        password: '',
        database: 'PHPlesson'
    });
    return con;
}

// 后台部分开始

// 登录后台
exports.login = function(params, res) {
    var sql = 'select * from login where username =? and password=?';
    openCon().query(sql, params, function(error, results5) {
        if (error) {
            console.log(error);
            res.end();
        } else {
            console.log("login ok");
            res.json("login ok");
            res.end();
        }
    });
};


// 添加
exports.adminadd = function(params, res) {
    var sql = 'INSERT INTO `phplesson`.`news` (`title`, `desc`, `img`, `content`, `time`, `type`) VALUES ( ?, ?, ?, ?, ?, ?)';
    openCon().query(sql, params, function(error, result) {
        if (error) {
            console.log(error);
            res.json(error);
        } else {
            console.log(params);
            res.json(result);
            res.end();
        }
    })
}


// 删除
exports.admindel = function(iddel, res) {
    var sql = 'DELETE FROM `news` WHERE `id` IN (' + iddel + ')';
    openCon().query(sql, function(error, result) {
        if (error) {
            console.log(error);
            res.end();
        } else {
            console.log('id' + iddel + '已删除');
            res.end();
        }
    })
}


// 修改
exports.adminupdate = function(idupdate, res) {
    var sql = 'SELECT * FROM NEWS WHERE ID = ' + idupdate + '';
    openCon().query(sql, function(error, result) {
        if (error) {
            console.log(error);
            res.json(error);
        } else {
            res.json(result);
            res.end();
        }
    })
}


exports.adminrep = function(req, res) {
    var sql = 'UPDATE `news` SET `title`=?,`desc`=?,`img`=?,`content`=?,`time`=?,`type`=? WHERE ID = ?';
    openCon().query(sql,req,function(error, result) {
        if (error) {
            console.log(error);
            res.json(error);
        } else {

            res.json(result);
            res.end();
        }
    })
}



// 查询
exports.adminquery = function(req, res) {
    var sql = 'SELECT * FROM news ORDER BY id DESC';
    openCon().query(sql, function(error, result) {
        if (error) {
            console.log(error);
            console.log(ord);
            res.end();
        } else {
            openCon().end();
            res.json(result);
            res.end();
        }
    });
};


exports.adminnav = function(req, res) {
    var sql = 'select type from news group by type';
    openCon().query(sql, function(error, result) {

        if (error) {
            console.log(error);
            //  console.log(ord);
            res.end();
        } else {
            openCon().end();
            res.json(result);
            res.end();

        }
    });
};

exports.adminmenu = function(type, res) {
    var sql = 'SELECT * FROM NEWS WHERE type = ?';
    openCon().query(sql, type, function(error, result) {
        console.log(result);
        if (error) {
            res.end();
        } else {
            openCon().end();
            res.json(result);
            res.end();

        }
    });
};


// 前台部分开始
// 


// 查询
exports.indexquery = function(req, res) {
    var sql = 'SELECT * FROM news ORDER BY id DESC';
    openCon().query(sql, function(error, result) {
        if (error) {
            console.log(error);
            console.log(ord);
            res.end();
        } else {
            openCon().end();
            res.json(result);
            res.end();
        }
    });
};


exports.indexnav = function(req, res) {
    var sql = 'select type from news group by type';
    openCon().query(sql, function(error, result) {

        if (error) {
            console.log(error);
            //  console.log(ord);
            res.end();
        } else {
            openCon().end();
            res.json(result);
            res.end();

        }
    });
};

exports.indexmenu = function(type, res) {
    var sql = 'SELECT * FROM NEWS WHERE type = ?';
    openCon().query(sql, type, function(error, result) {
        console.log(result);
        if (error) {
            res.end();
        } else {
            openCon().end();
            res.json(result);
            res.end();

        }
    });
};
