$(document).ready(function () {
    $('#loginBtn').click(function () {
        event.preventDefault();

        $.ajax({
            type: "post",
            url: "/login",
            data: {
                'username': $('#username').val(),
                'password': $('#password').val()
            },
            success: function (json) {
                var login =json;
                console.log(login);
                if (login == "login ok") {
                    alert("登录成功，欢迎回来！");
                    window.location.href="../admin.html";
                }else {
                    alert("登录错误，请检查信息");
                }
            }

        });
    });

});