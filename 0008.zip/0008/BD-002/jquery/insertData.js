//获取数据
function selectData(){
	
    $.ajax({
        type:'POST',
        url:'../phptest/mysql_select.php',
        dataType:'json',
   //      beforeSend:function(){
			// alert("数据请求中，稍等...");
   //      },
        success:function(data){
        	
            $("table#table").empty();
            $("table#table").html("<tr class='active'><td>删除</td><td>新闻标题</td><td>图片路径</td><td>新闻内容</td><td>添加时间</td></tr>");
            var tr="";
            //var list=data.list;
            $.each(data,function(index,array){
                tr+="<tr><td><button id='shanchu'>删除</button></td><td>"+array['newstitle']+"</td><td>"+array['newsimg']+"</td><td>"+array['newscontent']+"</td><td>"+array['addtime']+"</td></tr>";
            });
            $("table#table").append(tr);
        },
        error:function(){
            alert("请求数据失败...");
        }
    });
}

$("doucument").ready(function() {
    $("li.tianjia").click(function() {
       $("div.s-all").css("display","block");
       $("div.container-fluid").addClass("opa");
    });
    $("span.guanbi").click(function(){
        $("div.s-all").css("display","none");
        $("div.container-fluid").removeClass("opa");
    });
    
    $("li#select").click(function(){
    	selectData();
    });

    $("button#shanchu").click(function(){
    	alert(1);
    	// $("td#shanchu").each(function(){
    	// 	$.post("../phptest/mysql_delete.php",{name:newsid=$(this).index},function(data){
    	// 		alert(data.msg);
    	// 	});
    	// });
    	
    });
});


