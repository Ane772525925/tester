<?php
include("mysql_con.php");

// mysql_query("set names utf8");


$newsid = $_REQUEST['newsid'];

$sql="DELETE FROM news WHERE 'newsid'=".$newsid;


$result=mysql_query($sql,$con);

if (!$result){
	echo json_encode(array('msg'=>die('Error:'.mysql_error())));
}else{
  	echo json_encode(array('msg'=>"已经删除一条数据"));
}	

mysql_close($con);
?>
