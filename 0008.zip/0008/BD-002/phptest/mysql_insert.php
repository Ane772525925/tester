<?php
include("mysql_con.php");

// mysql_query("set names utf8");


$newstitle = $_REQUEST['newstitle'];
$newsimg = $_REQUEST['newsimg'];
$newscontent = $_REQUEST['newscontent'];
$addtime = $_REQUEST['addtime'];



$sql="INSERT INTO `news`(`newstitle`, `newsimg`, `newscontent`, `addtime`)VALUES('".$newstitle."','".$newsimg."','".$newscontent."','".$addtime."')";

$result=mysql_query($sql,$con);
if (!$result){
	die('Error:'.mysql_error());
}else{
  	echo "已经添加一条数据";
}	

mysql_close($con);
?>