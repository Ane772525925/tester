<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8" />
    <title>后台首页</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="./css/bootstrap.css" />
    <style rel="stylesheet" type="text/css">
    /*insert*/
        body{
            background-color:transparent;
        }
        div.s-all{
            width:300px!important;
            height:300px;
            border:1px solid #ccc;
            background-color:#f00;
            margin:100px auto;
        }
        tr.active>td{
            display:block;
        }
        input{
            width:360px;
            outline:0;
            border:1px #38f solid;
        }
        #newscontent{
            width:360px;
            height:120px;
            border:1px #38f solid;
        }
        input[type=submit]{
            width:420px;
            background:#38f;
            color:#fff;

        }
</style>
    <script type="text/javascript" src="./jquery/jquery-2.2.3.min.js"></script>
</head>
<body>
    <div id="s-all">
        <form name="insert" method="post" action="../phptest/mysql_insert.php">
            <table class="table" id="table">
                <tr class="active">
                    <td>新闻标题:<input type="text" name="newstitle" id="newstitle"/></td>
                    <td>图片地址:<input type="text" name="newsimg" id="newsimg"/></td>
                    <td>新闻内容:<textarea name="newscontent" id="newscontent"></textarea></td>
                    <td>添加时间:<input type="Date"  name="addtime" id="addtime"/></td>
                    <td><input type="submit" /></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>
