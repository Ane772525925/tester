<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8" />
    <title>后台首页</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="./css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="./css/admincss.css" />
    <script type="text/javascript" src="../jquery/jquery-2.2.3.min.js"></script>
    <script type="text/javascript" src="../jquery/insertData.js"></script>
    <!-- <script type="text/javascript" src="../jquery/selectjData.js"></script>
    <script type="text/javascript" src="../jquery/selectjData.js"></script> -->
</head>
<body>
    <div class="container-fluid">
        <!--头部关键部分 多余部分暂时去除了 -->
        <header class="row">
            <div class="navbar">
                <div class="guanli">管理中心</div>
            </div>
        </header>
        <div class="container-fluid">
            <div class="row">
                <aside>
                    <!-- 左边导航栏 -->
                    <div class="col-md-2">
                        <ul id="main-nav" class="nav nav-tabs nav-stacked" style="">
                            <li class="active">
                                <a href="#">
                                    <i class="glyphicon glyphicon-th-large"></i> 首页《新闻》
                                </a>
                            </li>
                            <li id="select">
                                <a href="#" class="nav-header collapsed" data-toggle="collapse">
                                    <i class="glyphicon glyphicon-cog"></i>&nbsp;&nbsp;&nbsp;&nbsp;查&nbsp;&nbsp;&nbsp;&nbsp;询
                                    <span class="pull-right glyphicon glyphicon-chevron-down"></span>
                                </a>
                            </li>
                            <li class="tianjia">
                                <a href="#">
                                    <i class="glyphicon glyphicon-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;添&nbsp;&nbsp;&nbsp;&nbsp;加
                                    <span class="pull-right glyphicon glyphicon-chevron-down"></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="glyphicon glyphicon-envelope"></i>&nbsp;&nbsp;&nbsp;&nbsp;删&nbsp;&nbsp;&nbsp;&nbsp;除
                                    <span class="pull-right glyphicon glyphicon-chevron-down"></span>
                                </a>
                            </li>
                            <li id="xiugai">
                                <a href="#">
                                    <i class="glyphicon glyphicon-calendar"></i>&nbsp;&nbsp;&nbsp;&nbsp;修&nbsp;&nbsp;&nbsp;&nbsp;改
                                    <span class="pull-right glyphicon glyphicon-chevron-down"></span>
                                </a>
                            </li>
                            <!-- <li>
                                <a href="#">
                                    <i class="glyphicon glyphicon-envelope"></i> 短信配置
                                    <span class="pull-right glyphicon glyphicon-chevron-down"></span>
                                </a>
                            </li> -->
                        </ul>
                    </div>
                    <!-- 主窗口 -->
                    <div class="col-md-10" id="s-all">
                        主窗口
                        <!-- <form id="all-update" name="all-update" method="post" action="../phptest/mysql_uadate.php"> -->
                            <table class="table table-bordered table-hover" id="table">
                                <tr class="active">
                                    <td>新闻标题</td>
                                    <td>图片路径</td>
                                    <td>添加时间</td>
                                    <td>新闻类别</td>
                                    <td>操作</td>
                                </tr>
                            </table>
                       <!--  </form> -->
                    </div>
                </aside>
            </div>
        </div>
    </div>
    <div class="s-all" style="display:none;">
        <span class="guanbi">X</span>
        <form id="insert" name="insert" method="post" action="../phptest/mysql_insert.php">
            <ul class="news-table" id="news-table">
                <li><label>新闻标题:</label><input type="text" name="newstitle" id="newstitle"/></li>
                <li><label>图片地址:</label><input type="text" name="newsimg" id="newsimg"/></li>
                <li><label>新闻内容:</label><textarea name="newscontent" id="newscontent"></textarea></li>
                <li><label>添加时间:</label><input type="Date"  name="addtime" id="addtime"/></li></li><br/>
                <li class="leibie" id="leibie"><label>新闻类别:</label>
                    <input type="radio" value="tuijian" name="newstype"/>推荐
                    <input type="radio" value="baijia" name="newstype"/>百家
                    <input type="radio" value="junshi" name="newstype"/>军事
                    <input type="radio" value="gaoxiao" name="newstype"/>搞笑
                </li><br/>
                <li><input type="submit" /></li>
            </ul>
        </form>
    </div>
</body>
</html>
