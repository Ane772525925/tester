<?php
header("Content-type:application/json;charset=utf-8");
//header("Content-type:text/html;charset=utf-8");

$con=mysql_connect("localhost","root","") or die("无法连接数据库:".mysql_error());

if(!$con){
	echo"无法连接数据库";
}else{
	mysql_select_db("phptestmysql",$con);
	mysql_query("set names utf8");
	//echo"已经连接数据库";
}
?>