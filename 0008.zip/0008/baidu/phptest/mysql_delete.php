<?php
require 'mysql_con.php';

// mysql_query("set names utf8");


$newsid = $_REQUEST['newsid'];//isset()?(int)$_REQUEST['newsid']:0;

echo "newsid:".$newsid;

$sql="DELETE FROM `news` WHERE `newsid`='".$newsid."'";

$result=mysql_query($sql,$con);
if (!$result){
	echo die('Error:'.mysql_error());
}else{
  	echo "删除成功";
}	

// if (!$result){
// 	echo json_encode(array('msg'=>"die('Error:'.mysql_error())"));
// }else{
//   	echo json_encode(array('msg'=>"已经删除一条数据"));
// }	

mysql_close($con);
?>
