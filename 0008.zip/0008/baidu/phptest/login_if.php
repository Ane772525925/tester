<?php

header("Content-type:application/json;charset=utf-8");

// $GLOBALS['b']="test";
session_start();
$_SESSION['views']=1;



$username = $_REQUEST['username'];

// 此处用户名验证可以用数据库数据验证
if($username=="admin"){
	echo json_encode(array('msg'=>'登陆成功','errorCode'=>true));
}else{
	echo json_encode(array('msg'=>'登陆失败','errorCode'=>false));
}

?>


