<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>登录页面</title>
    <link>
    <script type="text/javascript" href="./jquery/jquery-1.12.3.min.js"></script>
</head>
<body>
<form action="" method="post">
	
</form>
</body>
</html>