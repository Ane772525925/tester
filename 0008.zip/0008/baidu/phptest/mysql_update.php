<?php
require './mysql_con.php';

$newsid = isset($_REQUEST['newsid'])?(int)$_REQUEST['newsid']:0;

echo "newsid:".$newsid;

if($_POST){
	//接收到表单数据

	$newstitle = $_POST['newstitle'];
	$newsimg = $_POST['newsimg'];
	$newscontent = $_POST['newscontent'];
	$addtime = $_POST['addtime'];


	$result=mysql_query($sql,$con);
	$sql="UPDATE `news` SET `newstitle`='".$newstitle."','newsimg'='".$newsimg."' WHERE 'newsid'='".$newsid."'";
	if (!$result){
		echo "更新失败".mysql_error();
	}else{
	  	echo "已经更新了一条数据";
	}	
}

//无表单提交，查询数据显示到表单中
$sql="SELECT * FROM news WHERE newsid=".$newsid;

$result=mysql_query($sql,$con);

$arr = array();

while($row=mysql_fetch_array($result)){
	array_push($arr,array("newstitle"=>$row['newstitle'],"newsimg"=>$row['newsimg'],"newscontent"=>$row['newscontent'],"addtime"=>$row['addtime']));
}

//var_dump($arr);

header('Content-Type:text/html;charset=utf-8');
include './update_edit.html';

?>