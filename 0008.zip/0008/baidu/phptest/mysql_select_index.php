<?php
include("mysql_con.php");

mysql_query("set names utf8");


$newstype = $_REQUEST['newstype'];

$sql="SELECT `newstitle`, `newsimg`, `newscontent`, `addtime` FROM `news` WHERE `newstype`='".$newstype."'";

$result=mysql_query($sql,$con);

$arr = array();

$arr=mysql_fetch_array($result);

// while($row=mysql_fetch_array($result)){
// 	array_push($arr,array("newstitle"=>$row['newstitle'],"newsimg"=>$row['newsimg'],"newscontent"=>$row['newscontent'],"addtime"=>$row['addtime']));
// }

// if(!empty($arr)){
// 	print_r($arr);
	
// }else{
// 	echo "101";
// }

echo json_encode($arr);

mysql_close($con);
?>

