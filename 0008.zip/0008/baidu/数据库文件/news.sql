-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- 主机: 127.0.0.1
-- 生成日期: 2016 �?05 �?30 �?15:41
-- 服务器版本: 5.6.11
-- PHP 版本: 5.5.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `phptestmysql`
--

-- --------------------------------------------------------

--
-- 表的结构 `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `newsid` int(11) NOT NULL AUTO_INCREMENT COMMENT '自动增长',
  `newstitle` varchar(100) NOT NULL,
  `newsimg` varchar(500) NOT NULL,
  `newscontent` text NOT NULL,
  `addtime` date NOT NULL,
  `newstype` text NOT NULL,
  PRIMARY KEY (`newsid`),
  KEY `newstitle` (`newstitle`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='新闻表' AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `news`
--

INSERT INTO `news` (`newsid`, `newstitle`, `newsimg`, `newscontent`, `addtime`, `newstype`) VALUES
(1, '日本舰队遭遇不明物体跟踪 或是中国无人机', './img/timg.jpg', '为了更好的为读者呈现多样军事内容，满足读者不同阅读需求，共同探讨国内国际战略动态，新浪军事独家推出《深度军情》版块，深度解读军事新闻背后的隐藏态势', '2016-05-01', 'junshi'),
(2, '月球战争已经打响！中国还在犹豫', './img/timg.jpg', '50多年前，美国军队就试图在月球上建导弹基地和间谍中心；50多年后，美军高级将领重提“抢战太空阵地”研究太空武器，把战火燃烧到太空上去，在月球建立永久性军事基地，甚至把月球宣布为某国的领土……', '2016-05-01', 'tuijian'),
(3, '谷歌居然赢了Java案官司，这不科学！！', './img/timg.jpg', '美国旧金山联邦法庭陪审团做出裁决，认定安卓操作系统合理利用（fair use）JavaAPI代码并未侵犯其版权，驳回甲骨文向谷歌索赔93亿美元诉讼请求，', '2016-05-01', 'baijia'),
(4, '我在看我儿子会长什么样呢', './img/timg.jpg', '高中时女神是同桌,有一天我抬头发现她一直在瞅我傻笑,我生气列,问:看什么看,没见过帅锅么?她笑着答:我在看我儿子会长什么样呢?我:尼玛!滚!不带这样占便宜的!后来…后来…就没有后来了!现在想想我是不是错过了什么???', '2016-05-01', 'gaoxiao');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
