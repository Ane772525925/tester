//获取数据
function selectData() {

    $.ajax({
        type: 'POST',
        url: '../phptest/mysql_select.php',
        dataType: 'json',
        success: function(data) {

            $("table#table").empty();
            $("table#table").html("<tr class='active'><td>新闻标题</td><td>图片路径</td><td>添加时间</td><td>新闻类别</td><td>删除</td></tr>");
            var tr = "";
            //var list=data.list;
            $.each(data, function(index, array) {
                var m = array['newsid'];
                // console.log(m);
                tr += "<tr><td>" + array['newstitle'] + "</td><td>" + array['newsimg'] + "</td><td width='120'>" + array['addtime'] + "</td><td>"+array['newstype']+"</td><td><a href='../phptest/mysql_delete.php?newsid="+m+"'><input type=button value='删除' class='xiugai'></a><a href='../phptest/mysql_update.php?newsid="+m+"'><input type=submit value='修改' class='xiugai'></a></td></tr>";
            });
            $("table#table").append(tr);
        },
        error:function(){
            alert("请求数据失败...");
        }
    });
}
$("doucument").ready(function() {
    $("li.tianjia").click(function() {
        $("div.s-all").css("display", "block");
        $("div.container-fluid").addClass("opa");
    });
    $("span.guanbi").click(function() {
        $("div.s-all").css("display", "none");
        $("div.container-fluid").removeClass("opa");
    });

    $("li#select").click(function() {
        selectData();
    });

});