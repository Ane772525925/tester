//获取数据
function getData(){
    $.ajax({
        type:'POST',
        url:'../phptest/mysql_select.php',
        dataType:'json',
        beforeSend:function(){
            $("div#loading").html("<img id='timg' src='../baidu-news/img/timg.jpgs'/>");
        },
        success:function(){
            $("div#loading").html("");
            $("div#list ul").empty();
            var li="";
            //var list=json.list;
            $.each(data,function(index.array){
                li+="<li><img src'"+array['newsimg']+"'><p>"+array['newstitle']+"</p><article>"+array['newscontent']+"</article><p>"+array['addtime']+"</p></li>";
            });
            $("div#list ul").append(li);
        },
        error:function(){
            $("div#loading").html("<img id='timg' src='../baidu-news/img/timg.jpgs' />");
            $("div#list ul").html("请求数据失败...");
        }
    });
}
$("doucument").ready(function(){
    getData();
});

