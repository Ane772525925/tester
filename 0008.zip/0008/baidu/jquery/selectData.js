$(document).ready(function(){

    $(".fenlei span").on("click", function() {
        loadNews($(this).attr('data-target'));
    });
    //获取数据
    function loadNews(mess){
        $.ajax({
            type:'GET',
            url:'../phptest/mysql_select_index.php',
            data:{
                newstype:mess
            },
            dataType:'json',
            beforeSend:function(){
                $("div#loading").html("<img id='timg' src='./img/timg.jpg'/>");
            },
            success:function(data){
                $("div#loading").html();
                $("div#list ul").empty();
                var li="";

                li+="<li><img id='li-img' src='"+data['newsimg']+"'><p>"+data['newstitle']+"</p><article>"+data['newscontent']+"</article><p id='addtime'>"+data['addtime']+"</p></li>";

                $("div#list ul").append(li);
            },
            error:function(){
                $("div#loading").html("<img id='timg' src='../baidu-news/img/timg.jpg' />");
                $("div#list ul").html("请求数据失败...");
            }
        });
    }

    loadNews('tuijian');
});

        // <script type="text/javascript">
        // $(document).ready(function() {
        //     $(".fenlei span").on("click", function() {
        //         loadNews($(this).attr('data-target'));
        //     });

        //     function loadNe11ws() {
        //         $.get('../phptest/mysql_select_index.php', {
        //             newstype:"mess"
        //         }, function(data) {
        //             var li = "";
        //             $.each(data, function(index, array) {
        //                 li += "<li><img id='li-img' src='" + array['newsimg'] + "'><p>" + array['newstitle'] + "</p><article>" + array['newscontent'] + "</article><p id='addtime'>" + array['addtime'] + "</p></li>";
        //             });
        //             $("div#list ul").append(li);
        //         },"json");
        //     }
        //     //默认加载推荐类的新闻
            
        // });
        // </script>