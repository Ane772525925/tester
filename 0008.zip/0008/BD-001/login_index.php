<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>后台登陆</title>
    <link rel="stylesheet" type="text/css" href="./admin/css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="./admin/css/style.css" />
    <script type="text/javascript" src="./jquery/jquery-2.2.3.min.js"></script>
</head>
<body>
<!-- 简约派 -->
    <div class="container">
        <div class="row center-block">
        <!-- 表单入口 -->
            <form action="./phptest/login_if.php" method="post">
                <div class="form-group col-xs-14">
                    <label for="username"><h4 class="bg-primary">登录账号:</h4></label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="-----战舰---编号-----"/>
                </div>
                <div class="form-group col-xs-14">
                    <label for="password"><h4 class="bg-primary">登陆密码:</h4></label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="-----舰体---密文-----" />
                </div>
                <div>
                    <button type="submit" class="btn btn-success btn-lg btn-block" id="btn">登陆联盟总部</button>
                </div>
            </form>
        </div>
    </div>
    <script type="text/javascript">
        $("#btn").click(function(e){
            e.preventDefault();
            //alert(1);
            $.ajax({
                url:'./phptest/login_if.php',
                data:{
                    username:$('#username').val()
                },
                dataType:"json",
                type:'post',
                success:function(data){
                    alert(data.msg);
                    if(data.errorCode){
                        window.location.href='./admin/admin.html';
                    }
                },
                error:function(data){
                    alert(data.msg);
                    
                }
            });
        });   
    </script>
</body>
</html>
