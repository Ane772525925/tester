<?php
include("mysql_con.php");

// mysql_query("set names utf8");


$newsid = $_REQUEST['newsid'];

$sql="DELETE FROM news WHERE 'newsid'=".$newsid;


$result=mysql_query($sql,$con);

if (!$result){
	die('Error:'.mysql_error());
}else{
  	echo "已经删除一条数据";
}	

mysql_close($con);
?>
