$("#btn").click(function(e) {
    e.preventDefault();
    //alert(1);
    $.ajax({
        url: './phptest/login_if.php',
        data: {
            username: $('#username').val()
        },
        dataType: "json",
        type: 'post',
        success: function(data) {
            alert(data.msg);
            if (data.errorCode) {
                window.location.href = './admin/admin.html';
            }
        },
        error: function(data) {
            alert(data.msg);

        }
    });
});