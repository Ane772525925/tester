<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8" />
    <title>后台首页</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="./css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="./css/admincss.css" />
    <script type="text/javascript" src="./jquery/jquery-2.2.3.min.js"></script>
    <script type="text/javascript" src="../jquery/myjs.js"></script>
</head>
<body>
    <div class="container-fluid">
        <!--头部关键部分 多余部分暂时去除了 -->
        <header class="row">
            <div class="navbar">
                <div class="guanli">管理中心</div>
            </div>
        </header>
        <div class="container-fluid">
            <div class="row">
                <aside>
                    <!-- 左边导航栏 -->
                    <div class="col-md-2">
                        <ul id="main-nav" class="nav nav-tabs nav-stacked" style="">
                            <li class="active">
                                <a href="#">
                                    <i class="glyphicon glyphicon-th-large"></i> 首页《新闻》
                                </a>
                            </li>
                            <li>
                                <a href="#" class="nav-header collapsed" data-toggle="collapse">
                                    <i class="glyphicon glyphicon-cog"></i>&nbsp;&nbsp;&nbsp;&nbsp;查&nbsp;&nbsp;&nbsp;&nbsp;询
                                    <span class="pull-right glyphicon glyphicon-chevron-down"></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="glyphicon glyphicon-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;添&nbsp;&nbsp;&nbsp;&nbsp;加
                                    <span class="pull-right glyphicon glyphicon-chevron-down"></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="glyphicon glyphicon-envelope"></i>&nbsp;&nbsp;&nbsp;&nbsp;删&nbsp;&nbsp;&nbsp;&nbsp;除
                                    <span class="pull-right glyphicon glyphicon-chevron-down"></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="glyphicon glyphicon-calendar"></i>&nbsp;&nbsp;&nbsp;&nbsp;修&nbsp;&nbsp;&nbsp;&nbsp;改
                                    <span class="pull-right glyphicon glyphicon-chevron-down"></span>
                                </a>
                            </li>
                            <!-- <li>
                                <a href="#">
                                    <i class="glyphicon glyphicon-envelope"></i> 短信配置
                                    <span class="pull-right glyphicon glyphicon-chevron-down"></span>
                                </a>
                            </li> -->
                        </ul>
                    </div>
                    <!-- 主窗口 -->
                    <div class="col-md-10">
                        主窗口
                        <table class="table table-bordered table-hover">
                            <tr class="active">
                                <td class="">1</td>
                                <td class="">...</td>
                                <td class="">...</td>
                                <td class="">...</td>
                                <td class="">...</td>
                            </tr>
                            <tr class="active">
                                <td class="">2</td>
                                <td class="">...</td>
                                <td class="">...</td>
                                <td class="">...</td>
                                <td class="">...</td>
                            </tr>
                            <tr class="active">
                                <td class="">3</td>
                                <td class="">...</td>
                                <td class="">...</td>
                                <td class="">...</td>
                                <td class="">...</td>
                            </tr>
                            <tr class="active">
                                <td class="">4</td>
                                <td class="">...</td>
                                <td class="">...</td>
                                <td class="">...</td>
                                <td class="">...</td>
                            </tr>
                            <tr class="active">
                                <td class="">5</td>
                                <td class="">...</td>
                                <td class="">...</td>
                                <td class="">...</td>
                                <td class="">...</td>
                            </tr>
                        </table>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</body>
</html>
