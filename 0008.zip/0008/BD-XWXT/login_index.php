<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>后台登陆</title>
    <link rel="stylesheet" type="text/css" href="./admin/css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="./admin/css/style.css" />
    <script type="text/javascript" href="./jquery/jquery-1.12.3.min.js"></script>
</head>
<body>
<!-- 简约派 -->
    <div class="container">
        <div class="row center-block">
        <!-- 表单入口 -->
            <form action="./phptest/login_if.php" method="post">
                <div class="form-group col-xs-14">
                    <label for="exampleInputEmail1"><h4 class="bg-primary">登录账号:</h4></label>
                    <input type="email" class="form-control" id="exampleInputEmail1" name="username" placeholder="-----战舰---编号-----"/>
                </div>
                <div class="form-group col-xs-14">
                    <label for="exampleInputPassword1"><h4 class="bg-primary">登陆密码:</h4></label>
                    <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="-----舰体---密文-----" />
                </div>
                <!-- 暂时不做跳转 -->
                <div>
                    <button type="submit" class="btn btn-success btn-lg btn-block" id="btn">登陆联盟总部</button>
                </div>
            </form>
        </div>
    </div>
    <script type="text/javascript">
        $('#btn').click(function(e){
            e.preventDefault();
            $.ajax({
                url:'./phptest/login_if.php',
                data:{
                    username:$('#username').val();
                },
                dataType:"json",
                type:'post',
                success:function(data){
                    console.log(data);
                },
                error:function(){
                    alert('登录失败');
                }
            });
        });
    </script>
</body>
</html>
