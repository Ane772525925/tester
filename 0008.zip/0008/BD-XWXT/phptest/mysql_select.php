<?php
include("mysql_con.php");

// mysql_query("set names utf8");



$sql="SELECT * FROM news"

$result=mysql_query($sql,$con);



$arr = array();

while($row=mysql_fetch_array($result)){
	array_push($arr,array("newstitle"=>$row['nestitle'],"newsimg"=>$row['newsimg'],"newscontent"=>$row['newscontent'],"addtime"=>$row['addtime']));
}

$result=array("errcode"=>0,"result"=>$arr);

echo json_encode($result);

mysql_close($con);
?>

