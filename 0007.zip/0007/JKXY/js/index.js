// $("#listBox").imageScroller({
//                 next: "btnNext",
//                 prev: "btnPrev",
//                 frame: "list",
//                 child: "li",
//                 auto: true
//             });


jQuery.fn.imageScroller = function(params) {
    var p = params || {
        next: "buttonNext",
        prev: "buttonPrev",
        frame: "viewerFrame",
        child: "a",
        auto: true
    };
    var _btnNext = $("#" + p.next);
    var _btnPrev = $("#" + p.prev);
    var _imgFrame = $("#" + p.frame);
    var _child = p.child;
    var _auto = p.auto;
    var _itv;

    var turnLeft = function() {
        _btnPrev.unbind("click", turnLeft);
        if (_auto) autoStop();
        _imgFrame.animate({ marginLeft: -95 }, 'fast', '', function() {
            _imgFrame.find(_child + ":first").appendTo(_imgFrame);
            _imgFrame.css("marginLeft", 0);
            _btnPrev.bind("click", turnLeft);
            if (_auto) autoPlay();
        });
    };

    var turnRight = function() {
        _btnNext.unbind("click", turnRight);
        if (_auto) autoStop();
        _imgFrame.find(_child + ":last").clone().show().prependTo(_imgFrame);
        _imgFrame.css("marginLeft", -95);
        _imgFrame.animate({ marginLeft: 0 }, 'fast', '', function() {
            _imgFrame.find(_child + ":last").remove();
            _btnNext.bind("click", turnRight);
            if (_auto) autoPlay();
        });
    };

    _btnNext.css("cursor", "hand").click(turnRight);
    _btnPrev.css("cursor", "hand").click(turnLeft);

    var autoPlay = function() {
        _itv = window.setInterval(turnLeft, 3000);
    };
    var autoStop = function() {
        window.clearInterval(_itv);
    };
    if (_auto) autoPlay();
};



$(function() {
    $("div.bottom-left").hover(function() {
        $("div.bottom-up").css("display", "block");
    }, function() {
        $("div.bottom-up").css("display", "none");
    });
    $("div.bottom-up").hover(function() {
        $("div.bottom-up").css("display", "block");
    }, function() {
        $("div.bottom-up").css("display", "none");
    });

    $("div.bottom-left>.span").each(function(index) {
        $(this).hover(function() {
            $("li.panel-item").eq(index).children("span").addClass("angle").children("em").addClass("jt");
            $("li.panel-item").eq(index).addClass("panel");
        }, function() {
            $("li.panel-item").removeClass("panel");
            $("li.panel-item>span").removeClass("angle").children("em").removeClass("jt");
        });
    });

    $("li.panel-item").hover(function() {
        $(this).children("span").addClass("angle").children("em").addClass("jt");
        $(this).addClass("panel");
    }, function() {
        $("li.panel-item").removeClass("panel");
        $("li.panel-item>span").removeClass("angle").children("em").removeClass("jt");
    });
    $("div.bgimg>img").each(function(index) {
        $(this).hover(function() {
            $("div.desc").eq(index).css("display", "block");
        }, function() {
            $("div.desc").css("display", "none");
        });
    });
    /*------div.body-----div.gongkaike--------动画*/

    $("div.gongkaike>ul>div").each(function(index) {
        $(this).mouseenter(function() {

            // console.log(index);
            $(this).children("li").addClass("qie");
            $(this).children("div").addClass("g-green").children("span").addClass("g-jt");
            $(this).siblings().children("li").removeClass("qie");
            $(this).siblings().children("div").removeClass("g-green").children("span").removeClass("g-jt");
            $("div.gongkaike>ul>div").parents("div.gongkaike").children("div.zuixinke").eq(index).css("display", "block").siblings("div.zuixinke").css("display", "none");

            //console.log($("li.g").eq(index));
            // $("div.zuixinke").css("display","none");
        });
    });
    /*------div.body-----div.zhiye--------动画*/
    $("div.WEB").hover(function() {
        $(this).children("span").addClass("lj-hover");
    }, function() {
        $("div.WEB>span").removeClass("lj-hover");
    });
    /*------div.body-----div.jingpin--------动画*/
    $("div.ios").each(function(index) {
        $(this).hover(function() {
            $("div.ios-hover").eq(index).css("display", "block");
        }, function() {
            $("div.ios-hover").css("display", "none");
        });
    });
    /*----------div.all------div.left------ div.left------*/
    $("div.lesson-classfiy-nav>ul>li").each(function(index){
        $("div.lesson-classfiy-nav>ul>li").eq(index).hover(function(){
            $(this).children("div").children("div.lesson-list-show").css("display","block");
            $(this).children("div").children("div.slideright").addClass("xy");
        },function(){
            $("div.lesson-list-show").css("display","none");
            $("div.slideright").removeClass("xy");
        });
    });


    /*----------div.all------div.center------ div.center-top------*/
    $("div.center-top").hover(function() {
        $("ul.ct-img>li:first-child").css("display", "block").addClass("ct-lb-img-left");
        $("ul.ct-img>li:last-child").css("display", "block").addClass("ct-lb-img-right");
        // $("ul.ct-img>li:first-child").click(function(){
        //     var img_scroll = $("div.ct-lb-img>ul");
        //     //ul往左边移动
        //     img_scroll.animate({ marginLeft: "-560px" }, 100, function() {
        //         //把第一个li丢最后面去
        //         img_scroll.css({ marginLeft: 0 }).find("li:first-child").appendTo(img_scroll);
        //     });
        // });
        $("#listBox-ct").imageScroller({
            next: "btnPrev-ct",
            // prev: "btnNext-ct",
            frame: "list-ct",
            child: "li",
            auto: true
        });
    }, function() {
        $("ul.ct-img>li:first-child").css("display", "none").removeClass("ct-lb-img-left");
        $("ul.ct-img>li:last-child").css("display", "none").removeClass("ct-lb-img-right");
        // $("ul.ct-img>li:last-child").click(function(){
        //     var img_scroll = $("div.ct-lb-img>ul");
        //     //ul往左边移动
        //     img_scroll.animate({ marginLeft: "+560px" }, 100, function() {
        //         //把第一个li丢最后面去
        //         img_scroll.css({ marginLeft: 0 }).find("li:last-child").prependTo(img_scroll);
        //     });
        // });
        $("#listBox-ct").imageScroller({
            // next: "btnPrev-ct",
            prev: "btnNext-ct",
            frame: "list-ct",
            child: "li",
            auto: true
        });
    });
    // $("#listBox-ct").imageScroller({
    //     next: "btnPrev-ct",
    //     prev: "btnNext-ct",
    //     frame: "list-ct",
    //     child: "li",
    //     auto: false
    // });

    /*----------div.all------div.center------ div.center-bottom------*/
    $("div.center-bottom").hover(function() {
        $("ul.html-img>li:first-child").css("display", "block").addClass("html-lb-img-left");
        $("ul.html-img>li:last-child").css("display", "block").addClass("html-lb-img-right");
        // $("ul.html-img>li:first-child").click(function(){
        //     var img_scroll = $("div.html-lb-img>ul");
        //     //ul往左边移动300px
        //     img_scroll.animate({ marginLeft: "-186px" }, 100, function() {
        //         //把第一个li丢最后面去
        //         img_scroll.css({ marginLeft: 0 }).find("li:first-child").appendTo(img_scroll);
        //     });
        // });
    }, function() {
        $("ul.html-img>li:first-child").css("display", "none").removeClass("html-lb-img-left");
        $("ul.html-img>li:last-child").css("display", "none").removeClass("html-lb-img-right");
        // $("ul.html-img>li:last-child").click(function(){
        //     var img_scroll = $("div.html-lb-img>ul");
        //     //ul往左边移动300px
        //     img_scroll.animate({ marginLeft: "+186px" }, 100, function() {
        //         //把第一个li丢最后面去
        //         img_scroll.css({ marginLeft: 0 }).find("li:last-child").prependTo(img_scroll);
        //     });
        // });
    });
    $("#listBox-cb").imageScroller({
        next: "btnNext-cb",
        prev: "btnPrev-cb",
        frame: "list-cb",
        child: "li",
        auto: true
    });
    /*------div.right-bottom------动画*/
    $("ul.start-list>li.wenda").hover(function(){
        $("div.move-list").css("display","block");
    },function(){
        $("div.move-list").css("display","none");
    });

    $("div.content").mouseenter(function(){
        $(this).css("display","block");
        $(this).siblings("div").css("display","none");
    });

    $("ul.type-list>li").each(function(index){
        $(this).mouseenter(function(){
            $("ul.type-list>li").removeClass("add");
            $("div.content").css("display","none");
            $(this).addClass("add");
            $("div.content").eq(index).css("display","block");
            $(this).siblings().removeClass("add");
            $("div.content").eq(index).siblings("div").css("display","none");
        });
    });

    /*------div.hezuo-----div.meiti--------动画*/


    $("div.meiti").hover(function() {
        $("ul.lb-img>li:first-child").css("display", "block").addClass("lb-img-left");
        $("ul.lb-img>li:last-child").css("display", "block").addClass("lb-img-right");
        // $("ul.lb-img>li:first-child").click(function(){
        //      $("div.baodao>ul").animate({"margin-left":"-162px"},function(){

        //         $("div.baodao>ul li:eq(0)").appendTo($("div.baodao>ul"))
        //         $("div.baodao>ul").css({"margin-left":0})

        //     });
            // var img_scroll = $("div.baodao>ul");
            // //ul往左边移动300px
            // img_scroll.animate({ marginLeft: "-162px" }, 100, function() {
            //     //把第一个li丢最后面去
            //     img_scroll.css({ marginLeft: 0 }).find("li:first-child").appendTo(img_scroll);
            // });
        // });
    }, function() {
        $("ul.lb-img>li:first-child").css("display", "none").removeClass("lb-img-left");
        $("ul.lb-img>li:last-child").css("display", "none").removeClass("lb-img-right");
        $("ul.lb-img>li:last-child").click(function(){
            // var img_scroll = $("div.baodao>ul");
            // //ul往左边移动300px
            // img_scroll.animate({ marginLeft: "+162px" }, 100, function() {
            //     //把第一个li丢最后面去
            //     img_scroll.css({ marginLeft: 0 }).find("li:last-child").prependTo(img_scroll);
            // });
            
            $("div.baodao>ul").animate({"margin-left":"+162px"},function(){

                $("div.baodao>ul li:eq(7)").prependTo($("div.baodao>ul"))
                $("div.baodao>ul").css({"margin-left":0})

            });
        });
    });


    $("#listBox-meiti").imageScroller({
        next: "btnPrev-meiti",
        prev: "btnNext-meiti",
        frame: "list-meiti",
        child: "li",
        auto: false
    });
    /*------div.body-----div.zhishi--------动画*/

    /*------div.body-----div.zhishi--------动画*/
    var turn = function(target,time,opts){
        target.find('div.A-img').hover(function(){
            $(this).find('div.android-1').stop().animate(opts[0],time,function(){
                $(this).hide().next().show();
                $(this).next().animate(opts[1],time);
            });
        },function(){
            $(this).find('div.android-list').animate(opts[0],time,function(){
                $(this).hide().prev().show();
                $(this).prev().animate(opts[1],time);
            });
        });
    }
    var verticalOpts = [{'width':0},{'width':'166px'}];
    turn($('div.A-1'),800,verticalOpts);

});
        

 




