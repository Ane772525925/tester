$(document).ready(function() {
    $(window).on("load", function() {
        imgLoad();  // 排列图片
        // 图片原始数据
        var dataImg = { "data": [{ "src": "1.jpg" }, { "src": "2.jpg" }, { "src": "3.jpg" }, { "src": "4.jpg" }, { "src": "5.jpg" },{ "src": "6.jpg" },{ "src": "7.jpg" }] };
        window.onscroll = function() {
            // 添加元素并且排列
            if (scrollside()) {
                $.each(dataImg.data, function(index, value) {
                    var box = $("<div>").addClass("box").appendTo($("#container"));
                    var content = $("<div>").addClass("content").appendTo(box);
                    $("<img>").attr("src", "./img/" + $(value).attr("src")).appendTo(content);
                });
                // 加载图片，成图片瀑布流
                imgLoad();
            }
        };
    });
});
// 窗口自动调节
$(window).resize(function(){
    location.reload();
});
// 滚动加载图片
function scrollside() {
    var box = $(".box");
    var lastboxHeight = box.last().get(0).offsetTop + Math.floor(box.last().height() / 2); 
    var documentHeight = $(document).width();
    var scrollHeight = $(window).scrollTop();
    return (lastboxHeight < scrollHeight + documentHeight) ? true : false;
}
function imgLoad() {
    var box = $(".box");
    var boxWidth = box.eq(0).width();                    //盒子宽度
    var num = Math.floor($(window).width() / boxWidth);    //一行承列
    var boxArr = [];
    box.each(function(index, value) {                     //遍历每个图片
        var boxHeight = box.eq(index).height();
        if (index < num) {
            boxArr[index] = boxHeight;
        } else {
            var minboxHeight = Math.min.apply(null, boxArr);
            var minboxIndex = $.inArray(minboxHeight, boxArr);
            $(value).css({                                          //获取最低高度并定位排列
                "position": "absolute",
                "top": minboxHeight,
                "left": box.eq(minboxIndex).position().left
            });
            boxArr[minboxIndex] += box.eq(index).height();    //重新计算最低高度
        }
    });
}
