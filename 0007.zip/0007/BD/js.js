function setColor(color){
    if (window.localStorage) {
        localStorage.setItem("keyColor", color);
    } else {
        Cookie.write("keyColor", color);
    }
}

function getColor() {
    var color = window.localStorage ? localStorage.getItem("keyColor") : Cookie.read("keyColor");
    return color;
}



$(document).ready(function() {
    $(".xk").hover(function() {
        $(".zh").css("display", "block");
    }, function() {
        $(".zh").css("display", "none");
    });

    $(".zh").hover(function() {
        $(this).css("display", "block");
    }, function() {
        $(this).css("display", "none");
    });

    $(".set").hover(function() {
        $(".sz").css("display", "block");
    }, function() {
        $(".sz").css("display", "none");
    });

    $(".sz").hover(function() {
        $(this).css("display", "block");
    }, function() {
        $(this).css("display", "none");
    });


    $(".li_li").hover(function() {
        $(".tab").css("display", "block");
    }, function() {
        $(".tab").css("display", "none");
    });

    $(".tab").hover(function() {
        $(this).css("display", "block");
    }, function() {
        $(this).css("display", "none");
    });
    // 换肤
    $("div.p-pf img").click(function() {
        var imgSrc = $(this).attr("src").toString();
        // console.log(img);
        $("div.all").css({
            "background": "url(imgSrc)",
            "background-size":"cover"
        });
        var cimg=$("div.all").css("background")
        console.log(cimg);
    });

    // 中间内容
    $("div.h-1>li.span").each(function(index) {
        $(this).click(function() {
            $("li.span-span").removeClass("span-span");
            $(this).addClass("span-span");

            $("span.No-1").removeClass("No-1");
            $("div.content>span").eq(index).addClass("No-1");

            $("#span").children().removeClass("ren").addClass("ren-1"); //   ---002---
        });
    });

    $("li.span").hover(function() {
        $(this).addClass("span-s");
    }, function() {
        $(this).removeClass("span-s");
    });

    $("#span").hover(function() {
        $("#span>div").removeClass("ren").addClass("ren-1");
    }, function() {
        $("#span").children().removeClass("ren-1").addClass("ren"); //   ---001---   001和002冲突
    });

});